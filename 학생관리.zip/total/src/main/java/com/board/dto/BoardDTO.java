package com.board.dto;

import java.sql.Timestamp;

public class BoardDTO {
	
	private int seq;
	private String id;
	private int type;
	private String nickname;
	private String title;
	private String pass;
	private String content;
	private Timestamp writedate;
	private String filename;
	
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Timestamp getWritedate() {
		return writedate;
	}
	public void setWritedate(Timestamp writedate) {
		this.writedate = writedate;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	
	@Override
	public String toString() {
		return "BoardDTO [seq=" + seq + ", id=" + id + ", type=" + type + ", nickname=" + nickname + ", title=" + title
				+ ", pass=" + pass + ", content=" + content + ", writedate=" + writedate + ", filename=" + filename
				+ "]";
	}
}
